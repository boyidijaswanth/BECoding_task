<?php

require APPPATH . 'libraries/REST_Controller.php';

class Api extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->helper('url'); 
        $this->load->database();
    }

    public function getContact_get() { 
        $id = $this->input->get('id');
        if($this->input->get('data_store') == "database")
        {
            $data = $this->db->get_where("contacts",['id'=>$id])->row_array(); 
            $this->response($data, REST_Controller::HTTP_OK); 
        }
        elseif($this->input->get('data_store') == "CRM")
        {
            $curl = curl_init("https://smartbot.freshsales.io/api/contacts/".$id);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Token token=UMKfYq4QyBvo1kXY6fyQnQ',
                'Content-Type: application/json',
             ));
             $result = curl_exec($curl);
             $this->response($result, REST_Controller::HTTP_OK);
        } 
        else
        {
            $this->response({'message':'badReqest'}, REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function addContact_post()
    {
        if($this->input->get('data_store') == "database")
        {
            $this->load->model('Contacts_Model');
                
            $data = array( 
                'id' => $this->input->post('id'), 
                'firs_tname' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'), 
                'email' => $this->input->post('email'),
                'mobile_number' => $this->input->post('mobile_number'),
            );
            $this->Contacts_Model->insert($data);
            $myresp = $this->db->get("contacts")->result_array();
            $this->response($myresp, REST_Controller::HTTP_OK);
        }
        elseif($this->input->post('data_store') == "CRM")
        {
            $myArr = array(
                "contacts" => array(
                    "first_name" => $this->input->post('first_name'),
                    "last_name" => $this->input->post('last_name'),
                    "emails" => $this->input->post('email'),
                    "mobile_number" => $this->input->post('mobile_number')
                )
                );
            
            $data = json_encode($myArr);
            $curl = curl_init("https://smartbot.freshsales.io/api/contacts");
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: UMKfYq4QyBvo1kXY6fyQnQ',
                'Content-Type: application/json',
             ));
            $result = curl_exec($curl);
            $this->response($result, REST_Controller::HTTP_OK); 
        }
        else 
        {
            $this->response({"message":"badReqest"}, REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function updateContact_post()
    {
        if($this->input->post('data_store') == "database")
        {

            $this->load->model('Contacts_Model');

            $data = array( 
                'email' => $this->input->post('email'),
                'mobile_number' => $this->input->post('mobile_number'),
            ); 
                
            $id = $this->input->post('id'); 
            $this->Contacts_Model->update($data,$id);
            $myresp = $this->db->get("contacts")->result_array();
            $this->response($myresp, REST_Controller::HTTP_OK);
        }
        elseif($this->input->post('data_store') == "CRM")
        {
            $myArr = array(
                "contacts" => array(
                    "emails" => $this->input->post('email'),
                    "mobile_number" => $this->input->post('mobile_number')
                )
                );
            
            $data = json_encode($myArr);
            $curl = curl_init("https://smartbot.freshsales.io/api/contacts/".$this->input->post('id'));
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, false);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Token token=UMKfYq4QyBvo1kXY6fyQnQ',
                'Content-Type: application/json',
             ));
             $result = curl_exec($curl);
             $this->response($result, REST_Controller::HTTP_OK);
        }
        else
        {
            $this->response({'message':'badReqest'}, REST_Controller::HTTP_BAD_REQUEST);    
        }
    }

    public function deleteContact_post()
    {
        if($this->input->post('data_store') == "database")
        {

            $this->load->model('Contacts_Model'); 
            $id = $this->input->post('id'); 
            $this->Contacts_Model->delete($id); 
            $myresp = $this->db->get("contacts")->result_array();
            $this->response($myresp, REST_Controller::HTTP_OK); 
        }
        elseif($this->input->post('data_store') == "CRM")
        {       
            $curl = curl_init("https://smartbot.freshsales.io/api/contacts/".$this->input->post('id'));
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Authorization: Token token=UMKfYq4QyBvo1kXY6fyQnQ',
                'Content-Type: application/json',
             ));
             $result = curl_exec($curl);
             $this->response($result, REST_Controller::HTTP_OK);
        }
        else
        {
            $this->response({'message':'badReqest'}, REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}