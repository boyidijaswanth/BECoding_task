<?php 
   class Contacts_Model extends CI_Model {
	
      function __construct() { 
         parent::__construct(); 
        $this->load->database();
         $this->load->dbforge();
      } 
   
      public function insert($data) { 
         if ($this->db->insert("contacts", $data)) { 
            return true; 
         } 
      } 
   
      public function delete($contact_id) { 
         if ($this->db->delete("contacts", "id = ".$id)) { 
            return true; 
         } 
      } 
   
      public function update($data,$old_contact_id) { 
         $this->db->set($data); 
         $this->db->where("id", $old_id); 
         $this->db->update("contacts", $data);

      } 
   } 
?> 